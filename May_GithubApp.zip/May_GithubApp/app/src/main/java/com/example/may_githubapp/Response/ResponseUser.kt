package com.example.may_githubapp.Response

data class ResponseUser(
    val items : ArrayList<DataUser>
)
