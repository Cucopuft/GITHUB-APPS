package com.example.may_githubapp.Response

data class DataUser(
    val login : String,
    val id : Int,
    val avatar_url : String,
)
